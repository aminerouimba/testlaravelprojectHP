# Changelog

All notable changes to  `laravel-gymie`  will be documented in this file

## [](https://github.com/spatie/laravel-medialibrary/blob/master/CHANGELOG.md#690---2018-03-04)1.0.0 - 2018-03-09

- initial release