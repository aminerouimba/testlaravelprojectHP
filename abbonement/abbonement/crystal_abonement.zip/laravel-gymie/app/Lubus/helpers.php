<?php


/*
 * Set active page.
 *
 * @param string $uri
 * @return string
 */
